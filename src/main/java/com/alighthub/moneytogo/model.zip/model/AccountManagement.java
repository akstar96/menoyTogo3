package com.alighthub.moneytogo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Accountmanagement_details")
public class AccountManagement {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int accountmanagementid;
	private int status;/*1:activate, 0 : deactivate; -1 :delete*/
	private String accounttype;
	
	
	
	
	
	
	

}
