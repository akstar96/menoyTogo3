package com.alighthub.moneytogo.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Document_details")
public class Document {

	@Id
	private int  documentid;
	private String documenttype;
}
