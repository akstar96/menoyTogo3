package com.alighthub.moneytogo.model;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Employee_details")
public class Employee implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int empid;
	
	private String empname;
	
	private String currentaddress;
	private String permanentaddress;

	private Long mobileno;
	
	private Date birthdate;
	
    private String email;
    
    private  int pincode;
    
    private String pancard;
    
    private Long aadharcard;
    
    	
	@OneToOne(cascade = CascadeType.ALL)
	private Login login;
	
	
	@OneToOne(cascade = CascadeType.ALL)
	private AccountManagement accountmanagement;
	
	@OneToMany(cascade = CascadeType.ALL)
	private User user;
	
	@OneToMany(cascade = CascadeType.ALL)
	private Query query;


	

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname + ", currentaddress=" + currentaddress
				+ ", permanentaddress=" + permanentaddress + ", mobileno=" + mobileno + ", birthdate=" + birthdate
				+ ", email=" + email + ", pincode=" + pincode + ", pancard=" + pancard + ", aadharcard=" + aadharcard
				+ ", login=" + login + ", user=" + user + "]";
	}

	
	
	
	
	
}
