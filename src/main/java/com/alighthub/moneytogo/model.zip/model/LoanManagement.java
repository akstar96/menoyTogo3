package com.alighthub.moneytogo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LoanManagement_master")
public class LoanManagement {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int loanmanagementid;
	
	private String loantype;
	private float loaninterest;
	private long loanamount;
	private int loanduration;
	
	
	
	@Override
	public String toString() {
		return "LoanManagement [loanmanagementid=" + loanmanagementid + ", loantype=" + loantype + ", loaninterest="
				+ loaninterest + ", loanamount=" + loanamount + ", loanduration=" + loanduration + "]";
	}
	
	
}
