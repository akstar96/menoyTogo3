package com.alighthub.moneytogo.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "query_details")
public class Query {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int queryid;
	
	private String querysubject;
	private String query;
	
	@OneToOne(cascade = CascadeType.ALL)
	private User user;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Employee employee;
	
	
}
