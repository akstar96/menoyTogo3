package com.alighthub.moneytogo.model;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="User_details")
public class User implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int userid;

	private String username;
	
	private String currentaddress;
	private String permanentaddress;

	private Long mobileno;
	
	private Date birthdate;
	
    private String email;
    private  int pincode;
    
    private String pancard;
    
    private Long aadharcard;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Login login;
	
	@OneToMany(cascade = CascadeType.ALL)
	private Document document;
	
	@OneToMany(cascade = CascadeType.ALL)
	private Query query;
	
	@OneToOne(cascade = CascadeType.ALL)
	private AccountManagement accoutnmanagement;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Loan loan;
	
	
	
	
	
		
	
	

}
